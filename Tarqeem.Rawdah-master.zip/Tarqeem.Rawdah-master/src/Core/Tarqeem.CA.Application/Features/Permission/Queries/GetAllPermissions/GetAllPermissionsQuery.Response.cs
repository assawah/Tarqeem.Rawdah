namespace Tarqeem.CA.Application.Features.Permission.Queries.GetAllPermissions;

public record GetAllPermissionsQueryResponse(string Name, int Id);