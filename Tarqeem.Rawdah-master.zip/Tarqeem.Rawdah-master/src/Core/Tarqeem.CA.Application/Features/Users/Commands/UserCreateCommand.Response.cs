﻿namespace Tarqeem.CA.Application.Features.Users.Commands;

public class UserCreateCommandResponse
{
    public string UserGeneratedKey { get; set; }
}