namespace Tarqeem.CA.Application.Features.Rooms.Commands;

public record AddRoomCommandResponse(int RoomId);