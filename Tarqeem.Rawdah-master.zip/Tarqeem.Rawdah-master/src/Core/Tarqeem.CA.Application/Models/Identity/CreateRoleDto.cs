﻿namespace Tarqeem.CA.Application.Models.Identity;

public class CreateRoleDto
{
    public string RoleName { get; set; }
}