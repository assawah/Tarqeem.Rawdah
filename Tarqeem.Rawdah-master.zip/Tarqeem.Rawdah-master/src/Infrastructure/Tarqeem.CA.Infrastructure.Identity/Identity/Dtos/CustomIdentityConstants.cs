﻿namespace Tarqeem.CA.Infrastructure.Identity.Identity.Dtos
{
    internal class CustomIdentityConstants
    {
        public const string OtpPasswordLessLoginProvider = "PasswordlessLoginTotpProvider";
        public const string OtpPasswordLessLoginPurpose = "passwordless-auth";
    }
}
